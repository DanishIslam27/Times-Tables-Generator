import random, time

FullFinalList = []
CorrectList = []

print("Hi! Welcome to Bramalea STEM Club's times table practice!")
print()
ValueLimit = input("What is the maximum value of numbers used in the question ? : ")
print()
NumberOfQuestions = input("How many questions do you want to practice? : ")
print()

i = 1

def MultiplicationQuestion():
  num1 = random.randint(1, int(ValueLimit))
  num2 = random.randint(1, int(ValueLimit))

  AnswerKey = num1 * num2
  print(str(i) + ". What is " + str(num1) + " x " +  str(num2) + " ? : ")

  AttemptAnswer = input("What is the answer? : ")

  if int(AttemptAnswer) != AnswerKey:
    print("Incorrect! The answer is " + str(AnswerKey) + "!")
    result = "INCORRECT"
    
  elif int(AttemptAnswer) == AnswerKey:
    print("You are correct!")
    result = "CORRECT"
    CorrectList.append("c")


  FinalList = "Question " + str(i) + ". " + str(num1) + " x " +  str(num2) + " = " + str(AnswerKey) + ", " + result 
  FullFinalList.append(FinalList)

while i <= int(NumberOfQuestions):
  MultiplicationQuestion()
  print()
  i += 1

correct = len(CorrectList)

print("Thanks for playing!")
print()

print("You got " + str(correct) + " out of " + str(NumberOfQuestions) + " right.")
PercentCorrect = (float(correct) / float(NumberOfQuestions)) * 100
print()
print("Your percentage correct is " + str(PercentCorrect) + "%")
print()

if PercentCorrect <= 100 and PercentCorrect >= 85:
  print("On the Pakistani Grading Scale, that is...")
  print("A for Average!")
elif PercentCorrect < 85 and PercentCorrect >= 70:
  print("On the Pakistani Grading Scale, that is...")
  print("B for Bad!")
elif PercentCorrect < 70 and PercentCorrect >= 60:
  print("On the Pakistani Grading Scale, that is...")
  print("C for Chappal!")
elif PercentCorrect < 60 and PercentCorrect >= 50:
  print("On the Pakistani Grading Scale, that is...")
  print("D for Don't come home!")
elif PercentCorrect < 50:
  print("On the Pakistani Grading Scale, that is...")
  print("F for you are Flying home to Pakistan")

time.sleep(0.5)
print()
print("You know what Danish, you need math help. Ms. Cloutier holds math help sessions on Monday, Tuesday and Thursday from 7-8 pm. \nContact your math teacher for the Teams link.")


print()
SeeList = input("Do you want to see the full list of questions and answers? (y/n) : ")
print(FullFinalList)